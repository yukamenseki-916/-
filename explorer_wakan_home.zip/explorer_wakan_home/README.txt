探索者図鑑・トップページ試作

ファイル:
- index.html: トップページ（HTML/CSS/JavaScriptを内包）
- images/hero-main.png: メインビジュアル

使い方:
1. index.html と images フォルダを同じ場所に置いたままにしてください。
2. ご自身で左右反転したメインビジュアルを images/hero-main.png に上書きしてください。
3. index.html をブラウザで開くとトップページを確認できます。

メニューのリンク先 explorers.html / about.html は、次の制作段階で作成する予定です。
